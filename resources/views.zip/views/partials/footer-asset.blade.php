<!-- jquery -->
<script src="{{ asset('public/frontend/') }}/js/jquery-3.6.0.min.js"></script>
<!-- bootstrap js -->
<script src="{{ asset('public/frontend/') }}/js/bootstrap.bundle.min.js"></script>
<!-- swipper js -->
<script src="{{ asset('public/frontend/') }}/js/swiper.min.js"></script>
<!-- lightcase js-->
<script src="{{ asset('public/frontend/') }}/js/lightcase.js"></script>
<!-- tweenmax js-->
<script src="{{ asset('public/frontend/') }}/js/tweenmax.min.js"></script>
<!-- chart js -->
<script src="{{ asset('public/frontend/') }}/js/canvasjs.min.js"></script>
<!-- odometer js -->
<script src="{{ asset('public/frontend/') }}/js/odometer.min.js"></script>
<!-- viewport js -->
<script src="{{ asset('public/frontend/') }}/js/viewport.jquery.js"></script>
<!-- wow js file -->
<script src="{{ asset('public/frontend/') }}/js/wow.min.js"></script>
<script src="{{ asset('public/backend/library/popup/jquery.magnific-popup.js') }}"></script>
<!-- nice select js -->
<script src="{{ asset('public/frontend/js/jquery.nice-select.js') }}"></script>
<script src="{{ asset('public/backend/js/select2.min.js') }}"></script>
<!-- main -->
<script src="{{ asset('public/frontend/') }}/js/main.js"></script>



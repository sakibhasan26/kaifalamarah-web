<div class="copyright-wrapper">
    <div class="copyright-area">
        <p> {{ __("Developed by") }} <a href="https://appdevs.net">KM Team.</a></p>
        <p>{{ $basic_settings->site_name ?? 'AppDevs' }} <span>V{{ $basic_settings->web_version ?? '1.0.0' }}</span></p>
    </div>
</div>

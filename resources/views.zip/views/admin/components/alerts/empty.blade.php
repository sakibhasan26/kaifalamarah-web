<tr>
    <td colspan="{{ $colspan ?? "" }}"><div class="alert alert-primary justify-content-center text-center" style="margin-top: 37.5px">{{ __("No data found!") }}</div></td>
</tr>
